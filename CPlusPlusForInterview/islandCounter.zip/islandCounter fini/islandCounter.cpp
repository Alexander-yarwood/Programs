// islandCounter.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;


void areaCheck(char map[][50], int i, int j, bool checkedChar[][50]) {
	static int rowChecker[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
	static int colChecker[] = { -1, 0, 1, -1, 1, -1, 0, 1 };

	checkedChar[i][j] = true;

	for (int k = 0; k < 8; ++k) {
		if (((i + rowChecker[k]) >= 0) && ((i + rowChecker[k]) < 80) && ((j + colChecker[k]) >= 0) && ((j + colChecker[k]) < 50) && (map[(i + rowChecker[k])][(j + colChecker[k])] != '.' && !checkedChar[(i + rowChecker[k])][(j + colChecker[k])])) {
			areaCheck(map, i + rowChecker[k], j + colChecker[k], checkedChar);
		}

	}
	

}

int islandCount(char map[80][50]) {

	bool checkedChar[80][50];
	memset(checkedChar, 0, sizeof(checkedChar));

	int landMass = 0;



	for (int i = 0; i < 80; ++i) {
		for (int j = 0; j < 50; ++j)

			if (map[i][j] != '.' && !checkedChar[i][j]) {

				areaCheck(map, i, j, checkedChar);

				++landMass;
			}
	}
	return landMass;
}




int main(int argc, char* argv[])
{

	if (argc != 2)
	{
		cout << "arg count:" << argc <<"\n";
		cout << "usage: IslandCounter <mapFile1.txt>\n";
	}
	else {
		
		ifstream the_file(argv[1]);
		if (!the_file.is_open())
			cout << "Could not open file\n";
		else {
			int xPos = 0;
			int yPos = 0;
			int rows = 80;
			int cols = 50;
			int testWidth = 80;
			int testHeight = 50;
			int seaCount = 0;
			int landCount = 0;
			int treeCount = 0;
			int mountainCount = 0;
			int buildingCount = 0;
			int emptyLand = 0;
			char mapLine[80][50];
			char mapCurrent;
			

			cout << "--------------------------------------------------------" << '\n';
			cout << "islandCounter application developed by Alexander Yarwood" << '\n';
			cout << "--------------------------------------------------------" << '\n';

			while (the_file.get(mapCurrent)) {
				if (mapCurrent != '\n') {
					mapLine[xPos][yPos] = mapCurrent;
				}
				++xPos;
				if (mapCurrent == '.') {
					++seaCount;
				}
				else if (mapCurrent != '\n') {
					++landCount;
					if (mapCurrent == '*') {
						++treeCount;
					}
					else if (mapCurrent == '^') {
						++mountainCount;
					}
					else if (mapCurrent == '@') {
						++buildingCount;
					}
					else {
						++emptyLand;
					}
				}
				if (mapCurrent == '\n') {
					xPos = 0;
					++yPos;
				}

				if (yPos > rows ) {
					cerr << "y position out of bounds " << yPos << '/n';
					exit(1);
				}
			}







			
			cout << "Trees:" << treeCount << '\n';
			cout << "Mountains:" << mountainCount << '\n';
			cout << "Buildings:" << buildingCount << '\n';
			cout << "Land:" << emptyLand << '\n';
			cout << "Sea characters:" << seaCount << '\n';
			cout << "Island characters:" << landCount << '\n';
			cout << "Total amount of Landmasses:" << islandCount(mapLine);
			/*
			for (int i = 0; i < testHeight; ++i)
			{
				for (int j = 0; j < testWidth; ++j)
				{
					cout << mapLine[j][i];
				}
				cout << '\n';
			}
			*/
			// test used to display the contents of the 2d array
				
		}
	}
	return 0;
	
}



